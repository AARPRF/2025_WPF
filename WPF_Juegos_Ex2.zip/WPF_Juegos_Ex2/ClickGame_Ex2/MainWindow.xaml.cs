﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace ClickGame_Ex2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        //1. Generar los elementos del interfaz gráfico
        //2. Declaración de variables      
        DispatcherTimer gameTimer = new DispatcherTimer(); 
        List<Ellipse> removeThis = new List<Ellipse>();

        //3 Declaración de integers necesarios para el juego
        int spawnRate = 60; // default spawn rate of the circles
        int currentRate; // current rate will help add an interval between spawning of the circles
        int lastScore = 0; // this will hold the last played score for this game
        int health = 350; // total health of the player in the begining of the game
        int posX; // x position of the circles
        int posY; // y position of the circles
        int score = 0; // current score for the game
        double growthRate = 0.6; // the default growth rate for each circle in the game
        Random rand = new Random(); // a random number generator

        //4. Declaración de dos media player
        MediaPlayer playClickSound = new MediaPlayer();
        MediaPlayer playerPopSound = new MediaPlayer();

        //5. Dos URI (Idenficador de recursos uniforme ) location classes para ambos archviso mp3
        //importados para el juego
        Uri ClickedSound;
        Uri PoppedSound;

        //6.

        public MainWindow()
        {
            InitializeComponent();
        }
    }
}